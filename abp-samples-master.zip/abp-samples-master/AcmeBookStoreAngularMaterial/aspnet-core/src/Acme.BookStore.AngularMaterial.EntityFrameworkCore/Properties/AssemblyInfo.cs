﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Acme.BookStore.AngularMaterial.EntityFrameworkCore.Tests")]
