﻿namespace Acme.BookStore.AngularMaterial
{
    public static class AngularMaterialDomainErrorCodes
    {
        public const string AuthorAlreadyExists = "AngularMaterial:00001";
        /* You can add your business exception error codes here, as constants */
    }
}
