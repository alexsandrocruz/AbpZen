namespace Acme.BookStore.AngularMaterial.Authors
{
    public static class AuthorConsts
    {
        public const int MaxNameLength = 64;
    }
}