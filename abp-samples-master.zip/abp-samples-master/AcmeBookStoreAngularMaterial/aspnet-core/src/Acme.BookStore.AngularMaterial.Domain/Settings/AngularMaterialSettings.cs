﻿namespace Acme.BookStore.AngularMaterial.Settings
{
    public static class AngularMaterialSettings
    {
        private const string Prefix = "AngularMaterial";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}