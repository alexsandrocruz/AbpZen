﻿namespace Acme.BookStore.AngularMaterial
{
    public abstract class AngularMaterialDomainTestBase : AngularMaterialTestBase<AngularMaterialDomainTestModule> 
    {

    }
}
