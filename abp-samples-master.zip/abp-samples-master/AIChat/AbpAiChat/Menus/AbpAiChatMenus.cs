﻿namespace AbpAiChat.Menus;

public class AbpAiChatMenus
{
    private const string Prefix = "AbpAiChat";
    public const string Home = Prefix + ".Home";


    //Add your menu items here...

}
