namespace AbpAiChat.Permissions;

public static class AbpAiChatPermissions
{
    public const string GroupName = "AbpAiChat";



    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
