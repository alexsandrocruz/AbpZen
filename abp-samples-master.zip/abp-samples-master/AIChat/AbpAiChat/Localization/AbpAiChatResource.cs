﻿using Volo.Abp.Localization;

namespace AbpAiChat.Localization;

[LocalizationResourceName("AbpAiChat")]
public class AbpAiChatResource
{
    
}