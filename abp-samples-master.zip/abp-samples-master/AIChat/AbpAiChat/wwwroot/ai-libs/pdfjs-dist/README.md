pdfjs-dist version 4.10.38
https://github.com/mozilla/pdf.js
License: Apache-2.0

To update, replace the files with an updated build from https://www.npmjs.com/package/pdfjs-dist
