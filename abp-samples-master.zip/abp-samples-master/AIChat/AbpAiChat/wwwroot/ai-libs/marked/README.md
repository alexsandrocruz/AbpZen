marked version 15.0.6
https://github.com/markedjs/marked
License: MIT

To update, replace the files with with an updated build from https://www.npmjs.com/package/marked
