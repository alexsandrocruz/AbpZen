dompurify version 3.2.4
https://github.com/cure53/DOMPurify
License: Apache 2.0 and Mozilla Public License 2.0

To update, replace the files with an updated build from https://www.npmjs.com/package/dompurify
