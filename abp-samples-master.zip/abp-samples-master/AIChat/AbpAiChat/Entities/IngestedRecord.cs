namespace AbpAiChat.Entities;


public class IngestedRecord
{
    public required string Id { get; set; }

    public required string DocumentId { get; set; }
}
