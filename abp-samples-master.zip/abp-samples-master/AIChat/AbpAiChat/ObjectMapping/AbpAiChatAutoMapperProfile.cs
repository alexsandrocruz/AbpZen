﻿using AutoMapper;

namespace AbpAiChat.ObjectMapping;

public class AbpAiChatAutoMapperProfile : Profile
{
    public AbpAiChatAutoMapperProfile()
    {
        /* Create your AutoMapper object mappings here */
    }
}
