dotnet run --project AbpAiChat --migrate-database

exit $LASTEXITCODE