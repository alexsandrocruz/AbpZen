# Active Directory (LDAP) Test Application

This simple Dotnet application tests and troubleshoots your Active Directory (LDAP) settings. 
You can test them before entering your LDAP information on ABP's LDAP settings page.

**Related links:**
* https://github.com/abpframework/abp/issues/7209
* https://docs.abp.io/en/commercial/latest/modules/identity
* https://commercial.abp.io/modules/Volo.Identity.Pro
