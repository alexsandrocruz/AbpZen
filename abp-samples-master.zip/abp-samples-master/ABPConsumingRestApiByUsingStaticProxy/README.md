# Consuming HTTP APIs from a .NET Client Using ABP's Client Proxy System

This is an example project that demonstrates how to consume HTTP APIs from a .NET application using ABP's dynamic and static client-side proxy systems. See the article that explain this project:

**https://abp.io/community/posts/consuming-http-apis-from-a-.net-client-using-abps-client-proxy-system-xriqarrm**


