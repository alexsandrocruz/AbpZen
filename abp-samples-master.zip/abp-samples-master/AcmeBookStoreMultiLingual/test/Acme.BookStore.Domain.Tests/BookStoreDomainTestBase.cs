﻿namespace Acme.BookStore
{
    public abstract class BookStoreDomainTestBase : BookStoreTestBase<BookStoreDomainTestModule> 
    {

    }
}
