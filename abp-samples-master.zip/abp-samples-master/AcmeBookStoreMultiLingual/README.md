# How to Design Multi-Lingual Entity

This is an example project that demonstrates how to Design Multi-Lingual Entity. See the article that explain this project:

**https://abp.io/community/posts/how-to-design-multilingual-entity-8glnk6vu**
