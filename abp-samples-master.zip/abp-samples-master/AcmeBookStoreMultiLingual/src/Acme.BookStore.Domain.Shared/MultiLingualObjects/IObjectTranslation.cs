namespace Acme.BookStore.MultiLingualObjects;

public interface IObjectTranslation
{
    string Language { get; set; }
}